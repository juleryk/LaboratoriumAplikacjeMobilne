package com.example.myapplication4;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Toast;
import android.widget.Button;
public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button btnPrzycisk = (Button)findViewById(R.id.button);

        Toast toast = Toast.makeText (getApplicationContext (), "Eryk Kruszakin" ,
                Toast.LENGTH_SHORT);
        toast.setMargin ( 50 , 50 );

        btnPrzycisk.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                toast.show();
            }
        });

    }
}